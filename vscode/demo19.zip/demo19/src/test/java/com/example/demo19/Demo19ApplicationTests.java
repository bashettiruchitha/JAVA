package com.example.demo19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
