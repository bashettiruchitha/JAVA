package com.example.demo19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo19Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo19Application.class, args);
		System.out.println("helooo-------");
	}

}
